﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;

public partial class BarChart_BarChart : System.Web.UI.Page 
{

    protected void Page_Load(object sender, EventArgs e) {
        // first series
        //var barChartSeries = new BarChartSeries();
        //barChartSeries.Data = new decimal[] { 1, 2, 3, 4, 5, 6 };
        //barChartSeries.Name = "United States";
        //Chart1.Series.Add(barChartSeries);

        // second series
        //barChartSeries = new BarChartSeries();
        //barChartSeries.Data = new decimal[] { 5, 6, 7, 8, 9, 3 };
        //barChartSeries.Name = "Europe";
        //Chart1.Series.Add(barChartSeries);
    }    
    
}


